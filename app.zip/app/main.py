# main.py
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from bson import ObjectId
from .database import users_col, sections_col, tasks_col  # from your file

app = FastAPI()

# Allow frontend or any client to connect
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # change to your frontend URL in production
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

@app.get("/")
async def root():
    return {"message": "API is running"}

@app.get("/test-db")
async def test_db():
    # Just count each collection to check connection
    user_count = await users_col.count_documents({})
    section_count = await sections_col.count_documents({})
    task_count = await tasks_col.count_documents({})
    return {
        "users": user_count,
        "sections": section_count,
        "tasks": task_count
    }
